wp.blocks.registerBlockStyle('core/gallery', {
	name: 'deejay-hide-caption',
	label: wp.i18n.__('Hide captions', 'deejay')
});
